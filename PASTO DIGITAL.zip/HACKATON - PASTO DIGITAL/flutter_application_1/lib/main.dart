import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// --- Ponto de Entrada da Aplicação ---
void main() {
  runApp(const PastoDigitalApp());
}

// --- Dados Mock (Simulação de dados que viriam do IoT/Banco de Dados) ---

// Modelo para os Alertas do Painel
enum AlertLevel { info, warning, critical }

class Alerta {
  final IconData icon;
  final String title;
  final String message;
  final AlertLevel level;

  Alerta({
    required this.icon,
    required this.title,
    required this.message,
    required this.level,
  });
}

// Modelo para os Sensores
class Sensor {
  final String nome;
  final String local;
  final int bateria;
  final double umidade;
  final double temperatura;
  final String recomendacao;

  Sensor({
    required this.nome,
    required this.local,
    required this.bateria,
    required this.umidade,
    required this.temperatura,
    required this.recomendacao,
  });
}

// Lista de alertas para simulação
final List<Alerta> mockAlertas = [
  Alerta(
    icon: Icons.check_circle,
    title: 'Silo Principal: Qualidade ideal!',
    message: 'A silagem pode ser aberta para uso a partir de amanhã.',
    level: AlertLevel.info,
  ),
  Alerta(
    icon: Icons.warning,
    title: 'Talhão 2: Umidade baixa',
    message:
        'Considere irrigar nos próximos 2 dias para evitar estresse hídrico.',
    level: AlertLevel.warning,
  ),
  Alerta(
    icon: Icons.local_fire_department,
    title: 'Silo Novo: Temperatura Alta!',
    message: 'Risco de perda de qualidade. Verifique a vedação do silo.',
    level: AlertLevel.critical,
  ),
];

// Lista de sensores para simulação
final List<Sensor> mockSensores = [
  Sensor(
    nome: 'Sensor de Solo',
    local: 'Talhão Safrinha',
    bateria: 88,
    umidade: 62.5,
    temperatura: 27.1,
    recomendacao:
        'Níveis de umidade e temperatura ideais para esta fase da cultura.',
  ),
  Sensor(
    nome: 'Sensor de Silo',
    local: 'Silo Principal (Lote S-01)',
    bateria: 93,
    umidade: 68.2,
    temperatura: 33.5,
    recomendacao:
        'Temperatura estável. Fermentação de alta qualidade garantida.',
  ),
  Sensor(
    nome: 'Sensor de Bebedouro',
    local: 'Pasto 1',
    bateria: 75,
    umidade: 95.0,
    temperatura: 25.0,
    recomendacao: 'Nível da água está ótimo.',
  ),
];

// --- Widget Principal da Aplicação (Configura Tema) ---
class PastoDigitalApp extends StatelessWidget {
  const PastoDigitalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pasto Digital',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      home: const MainScreen(),
    );
  }

  // Método para construir o tema do aplicativo
  // COLE ESTA NOVA VERSÃO COMPLETA DA FUNÇÃO DE TEMA
  ThemeData _buildTheme() {
    final baseTheme = ThemeData.light();
    return baseTheme.copyWith(
      primaryColor: const Color(0xFF2E7D32), // Verde escuro
      scaffoldBackgroundColor: const Color(0xFFF5F7FA), // Fundo levemente cinza
      // Configuração de Textos com Google Fonts
      textTheme: GoogleFonts.poppinsTextTheme(baseTheme.textTheme).copyWith(
        displaySmall: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 28,
          color: Color(0xFF333333),
        ),
        headlineMedium: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 22,
          color: Color(0xFF333333),
        ),
        bodyLarge: const TextStyle(fontSize: 16, color: Color(0xFF555555)),
        bodyMedium: const TextStyle(fontSize: 14, color: Color(0xFF666666)),
      ),

      // Esquema de Cores
      colorScheme: const ColorScheme.light(
        primary: Color(0xFF2E7D32),
        secondary: Color(0xFFFFA000),
        surface: Colors.white,
        onSurface: Color(0xFF333333),
      ),

      // Tema para Cards
      cardTheme: CardThemeData(
        elevation: 2,
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
      ),

      // Tema para Botões Elevados
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF2E7D32),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          textStyle: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),

      // Tema para a Barra de Navegação Inferior
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        selectedItemColor: Color(0xFF2E7D32),
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
      ),
    );
  }
}

// --- Tela Principal com a Barra de Navegação ---
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    const DashboardScreen(),
    const SensoresScreen(),
    const Center(child: Text('Página do Rebanho em construção')), // Placeholder
    const Center(
      child: Text('Página dos Talhões em construção'),
    ), // Placeholder
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Início'),
          BottomNavigationBarItem(icon: Icon(Icons.sensors), label: 'Sensores'),
          BottomNavigationBarItem(icon: Icon(Icons.pets), label: 'Rebanho'),
          BottomNavigationBarItem(icon: Icon(Icons.grass), label: 'Talhões'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType
            .fixed, // Garante que todos os itens apareçam
      ),
    );
  }
}

// --- Tela 1: Painel de Controle (Dashboard) ---
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Painel de Controle',
          style: Theme.of(
            context,
          ).textTheme.headlineMedium?.copyWith(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Saudação
          Text(
            'Bem-vindo, Guilherme!',
            style: Theme.of(context).textTheme.displaySmall,
          ),
          const SizedBox(height: 24),

          // Seção de Alertas
          Text(
            'Alertas Recentes',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          ...mockAlertas
              .map((alerta) => _buildAlertCard(context, alerta))
              .toList(),

          const SizedBox(height: 24),

          // Seção de Resumo
          Text(
            'Resumo do Dia',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  context,
                  icon: Icons.opacity,
                  title: 'Produção de Leite',
                  value: '215 L',
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildSummaryCard(
                  context,
                  icon: Icons.restaurant_menu,
                  title: 'Alimentação',
                  value: 'Silo S-01',
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Seção de Atalhos
          Text(
            'Ações Rápidas',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 2.5,
            children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.add_circle_outline),
                label: const Text('Registrar Ordenha'),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.add_chart),
                label: const Text('Adubar Talhão'),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.description_outlined),
                label: const Text('Passaporte'),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.vaccines_outlined),
                label: const Text('Registrar Saúde'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Widget para os cards de alerta
  Widget _buildAlertCard(BuildContext context, Alerta alerta) {
    Color cardColor;
    switch (alerta.level) {
      case AlertLevel.info:
        cardColor = Colors.green.shade100;
        break;
      case AlertLevel.warning:
        cardColor = Colors.orange.shade100;
        break;
      case AlertLevel.critical:
        cardColor = Colors.red.shade100;
        break;
    }

    return Card(
      color: cardColor,
      child: ListTile(
        leading: Icon(
          alerta.icon,
          color: Theme.of(context).colorScheme.onSurface,
          size: 30,
        ),
        title: Text(
          alerta.title,
          style: Theme.of(
            context,
          ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          alerta.message,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      ),
    );
  }

  // Widget para os cards de resumo
  Widget _buildSummaryCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 32, color: Theme.of(context).primaryColor),
            const SizedBox(height: 8),
            Text(title, style: Theme.of(context).textTheme.bodyMedium),
            Text(
              value,
              style: Theme.of(
                context,
              ).textTheme.headlineMedium?.copyWith(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}

// --- Tela 2: Meus Sensores ---
class SensoresScreen extends StatelessWidget {
  const SensoresScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Meus Sensores',
          style: Theme.of(
            context,
          ).textTheme.headlineMedium?.copyWith(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () {
              // Lógica para adicionar um novo sensor
            },
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: mockSensores.length,
        itemBuilder: (context, index) {
          final sensor = mockSensores[index];
          return _buildSensorCard(context, sensor);
        },
      ),
    );
  }

  // Widget para o card de cada sensor
  Widget _buildSensorCard(BuildContext context, Sensor sensor) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Cabeçalho do Card
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      sensor.nome,
                      style: Theme.of(
                        context,
                      ).textTheme.headlineMedium?.copyWith(fontSize: 18),
                    ),
                    Text(
                      sensor.local,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(
                      Icons.battery_full,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${sensor.bateria}%',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const Divider(height: 24, thickness: 1),

            // Leituras do Sensor
            _buildSensorReading(
              context,
              icon: Icons.water_drop,
              label: 'Umidade',
              value: '${sensor.umidade}%',
            ),
            const SizedBox(height: 12),
            _buildSensorReading(
              context,
              icon: Icons.thermostat,
              label: 'Temperatura',
              value: '${sensor.temperatura}°C',
            ),

            const SizedBox(height: 16),

            // Recomendação
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    color: Theme.of(context).colorScheme.secondary,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      sensor.recomendacao,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget para cada linha de leitura
  Widget _buildSensorReading(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, color: Theme.of(context).primaryColor, size: 20),
        const SizedBox(width: 12),
        Text(label, style: Theme.of(context).textTheme.bodyLarge),
        const Spacer(),
        Text(
          value,
          style: Theme.of(
            context,
          ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
